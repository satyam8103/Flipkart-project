package org.reports;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ScreenshotUtil {

    public static String capture(WebDriver driver, String testName) {
        try {
            String screenshotsDir = "/reports/screenshots/";
            new File(screenshotsDir).mkdirs();

            String filePath = screenshotsDir + testName + ".png";

            File src = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
            Files.copy(src.toPath(), new File(filePath).toPath(), StandardCopyOption.REPLACE_EXISTING);

            return filePath;
        } catch (Exception e) {
            return null;
        }
    }
}