package org.reports;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import java.lang.reflect.Field;

public class ExtentTestNGListener implements ITestListener {

    private static final ExtentReports extent = ExtentManager.getExtentReports();
    private static ExtentTest test ;
    public void onTestStart(ITestResult result) {
        test= extent.createTest(result.getMethod().getMethodName());
        test.log(Status.INFO, "Test Started: " + result.getMethod().getMethodName());
    }

    @Override
    public void onTestSuccess(ITestResult result) {
        test.log(Status.PASS, "Test Passed");
        attachScreenshot(result, test, "PASS");
    }

    @Override
    public void onTestFailure(ITestResult result) {
        test.log(Status.FAIL, "Test Failed");
        test.fail(result.getThrowable());
        attachScreenshot(result, test, "FAIL");
    }

    @Override
    public void onTestSkipped(ITestResult result) {
        test.log(Status.SKIP, "Test Skipped");
        attachScreenshot(result, test, "SKIP");
    }

    @Override
    public void onFinish(ITestContext context) {
        extent.flush();
    }

    private void attachScreenshot(ITestResult result, ExtentTest test, String status) {
        WebDriver driver = extractDriver(result);

        if (driver == null) {
            test.log(Status.WARNING, "Driver not found - screenshot not captured.");
            return;
        }

        String path = ScreenshotUtil.capture(driver, status +  result.getMethod().getMethodName());
        if (path != null) {
            try {
                test.addScreenCaptureFromPath(path);

            } catch (Exception e) {
                test.log(Status.WARNING, "Could not attach screenshot: " + e.getMessage());
            }
        } else {
            test.log(Status.WARNING, "Screenshot capture returned null path.");
        }
    }

    private WebDriver extractDriver(ITestResult result) {
        try {
            Object testClassInstance = result.getInstance();
            Field driverField = testClassInstance.getClass().getField("driver");
            driverField.setAccessible(true);
            return (WebDriver) driverField.get(testClassInstance);
        } catch (Exception e) {
            return null;
        }
    }
}
