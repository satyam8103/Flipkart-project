package org.automation.testing.tests.flipkart.cart;

import org.automation.testing.baseclass.BaseTest;
import org.automation.testing.pages.FlipkartHomePage;
import org.automation.testing.pages.ProductPage;
import org.automation.testing.pages.SearchResultsPage;
import org.automation.testing.utility.BrowserUtils;
import org.automation.testing.utility.ConfigReader;
import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;


public class TC_003_CartTotalValidationTest extends BaseTest {
    private FlipkartHomePage homePage;
    private SearchResultsPage searchResultsPage;
    private ProductPage productPage;
    private String originalWindow;

    @Test(priority = 1, description = "Test: Cart Validation with Multiple Products")
    public void testCompleteCartValidation() throws InterruptedException {
        System.out.println("\n========== CART VALIDATION TEST STARTED ==========\n");
        
        driver.navigate().to(ConfigReader.getURL());
        originalWindow = driver.getWindowHandle();
        homePage = new FlipkartHomePage(driver);
        searchResultsPage = new SearchResultsPage(driver);
        productPage = new ProductPage(driver);

        // Check if homepage is alternative version (with protect element class)
        boolean isAlternativeHomepage = productPage.isAlternativeHomepage();
        System.out.println("Homepage Type: " + (isAlternativeHomepage ? "ALTERNATIVE (with Protect)" : "NORMAL"));

        String[] products = {  "vivo x300", "redmi 15", "whirlpool ac 1.5 ton" };
        int[][] prices = new int[products.length][2];
        int expectedTotal = 0;

        // Add each product and calculate total
        for (int i = 0; i < products.length; i++) {
            addProduct(products[i], i, prices, isAlternativeHomepage);
            expectedTotal += prices[i][0] + prices[i][1];
        }

        if (isAlternativeHomepage) {

            productPage.clickCartIcon();

            Thread.sleep(1500);

            // Validate final total
            int actualTotal = productPage.getCartFinalPrice();
            System.out.println("\nCart Validation Result:");
            System.out.println("Expected: Rs " + expectedTotal + " | Actual: Rs " + actualTotal);

            Assert.assertEquals(actualTotal, expectedTotal, "Cart total mismatch");
            System.out.println("\nCart Validation PASSED!");



            Thread.sleep(1000);
            BrowserUtils.takeScreenShot(driver, "TC_003_CartValidation");
        } else {
            // For normal homepage: perform same validation (print, assert, screenshot) without clicking cart
            System.out.println("Normal homepage detected - performing cart total check without clicking cart.");

            int actualTotal = productPage.getCartFinalPrice();
            System.out.println("\nCart Validation Result:");
            System.out.println("Expected: Rs " + expectedTotal + " | Actual: Rs " + actualTotal);

            Assert.assertEquals(actualTotal, expectedTotal, "Cart total mismatch");
            System.out.println("\nCart Validation PASSED!");

            Thread.sleep(1000); // Small delay before screenshot
            BrowserUtils.takeScreenShot(driver, "TC_003_CartValidation");
        }

        driver.close();
        driver.switchTo().window(originalWindow);
    }

    private void addProduct(String searchTerm, int index, int[][] prices, boolean isAlternativeHomepage) {
        if (index > 0) {
            goBackToHome();
            homePage.clearAndSearchProduct(searchTerm);
        } else {
            homePage.searchProduct(searchTerm);
        }

        BrowserUtils.waitForElementVisible(driver, ProductPage.RESULTS_LOCATOR);
        prices[index][0] = searchResultsPage.getFirstProductPriceFromResults();
        
        searchResultsPage.clickFirstProduct();
        BrowserUtils.switchToWindowByTitle(driver, searchTerm);

        if (isAlternativeHomepage) {
            // Use Protect locator for alternative homepage
            prices[index][1] = productPage.getProtectPrice();
            System.out.println("Protect price extracted: " + prices[index][1]);
        } else {
            // Use default locator for normal homepage
            prices[index][1] = productPage.getAdditionalPrice();
        }
        
        productPage.addToCart();
        System.out.println("Added " + searchTerm + " | Base: Rs " + prices[index][0] + 
                         " + Charges: Rs " + prices[index][1]);
    }
    private void goBackToHome() {
        driver.close();
        driver.switchTo().window(originalWindow);
        driver.navigate().to(ConfigReader.getURL());
        BrowserUtils.waitForElementVisible(driver, By.xpath("//*[@name=\"q\"]"));
    }
}