package org.automation.testing.tests.flipkart.search;

import org.automation.testing.baseclass.BaseTest;
import org.automation.testing.pages.FlipkartHomePage;
import org.automation.testing.utility.BrowserUtils;
import org.automation.testing.utility.ConfigReader;
import  org.automation.testing.pages.ProductPage;
import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;


public class TC_001_SearchProductTest extends BaseTest {
    private FlipkartHomePage homePage;

    @Test(priority = 1, description = "Test 1: Navigate to Flipkart Homepage")
    public void testNavigateToFlipkart() {
        System.out.println("\n========== SEARCH PRODUCT TEST STARTED ==========\n");
        System.out.println(">>> TEST 1: Navigating to Flipkart Homepage...");
        driver.navigate().to(ConfigReader.getURL());

        String pageTitle = driver.getTitle();
        System.out.println(" Page Title: " + pageTitle);

        Assert.assertTrue(pageTitle.contains("Online Shopping") || pageTitle.contains("Flipkart"),
            "Failed: Page title does not contain expected Flipkart titles");
        System.out.println(" Successfully navigated to Flipkart homepage");
                BrowserUtils.takeScreenShot(driver, "TC_001_Test_1_Homepage");

    }

    @Test(priority = 2, description = "Test 2: Search for Samsung S25 Ultra")
    public void testSearchSamsungS25() {
        System.out.println("\n>>> TEST 2: Searching for Samsung S25 Ultra...");

        homePage = new FlipkartHomePage(driver);
        String searchTerm = "samsung s25 ultra";

        homePage.searchProduct(searchTerm);
        System.out.println(" Entered search term: " + searchTerm);

        // Wait for results to appear
        BrowserUtils.waitForElementVisible(driver, ProductPage.RESULTS_LOCATOR);
        System.out.println(" Search results appeared");

        int resultCount = driver.findElements(ProductPage.RESULTS_LOCATOR).size();
        Assert.assertTrue(resultCount > 0,
                "Failed: No search results found for " + searchTerm);
        System.out.println(" Found " + resultCount + " search results");
        BrowserUtils.takeScreenShot(driver, "TC_001_Test_2_SearchResults");
    }

    @Test(priority = 3, description = "Test 3: Search for Apple iPhone 17")
    public void testSearchAppleIphone() {
        System.out.println("\n>>> TEST 3: Searching for Apple iPhone 17...");

        driver.navigate().to(ConfigReader.getURL());
        homePage = new FlipkartHomePage(driver);
        String searchTerm = "apple 17";

        homePage.searchProduct(searchTerm);
        System.out.println(" Entered search term: " + searchTerm);

        // Wait for results to appear
        BrowserUtils.waitForElementVisible(driver, ProductPage.RESULTS_LOCATOR);
        System.out.println(" Search results appeared");

        int resultCount = driver.findElements(ProductPage.RESULTS_LOCATOR).size();
        Assert.assertTrue(resultCount > 0,
                "Failed: No search results found for " + searchTerm);
        System.out.println(" Found " + resultCount + " search results");
        BrowserUtils.takeScreenShot(driver, "TC_001_Test_3_Apple");
    }

    @Test(priority = 4, description = "Test 4: Search for OnePlus Nord")
    public void testSearchOnePlusNord() {
        System.out.println("\n>>> TEST 4: Searching for OnePlus Nord...");

        driver.navigate().to(ConfigReader.getURL());
        homePage = new FlipkartHomePage(driver);
        String searchTerm = "oneplus nord";

        homePage.searchProduct(searchTerm);
        System.out.println(" Entered search term: " + searchTerm);

        BrowserUtils.waitForElementVisible(driver, ProductPage.RESULTS_LOCATOR);
        System.out.println(" Search results appeared");

        int resultCount = driver.findElements(ProductPage.RESULTS_LOCATOR).size();
        Assert.assertTrue(resultCount > 0,
                "Failed: No search results found for " + searchTerm);
        System.out.println(" Found " + resultCount + " search results");
        BrowserUtils.takeScreenShot(driver, "TC_001_Test_4_OnePlus");
    }

}
