package org.automation.testing.tests.flipkart.product;

import org.automation.testing.baseclass.BaseTest;
import org.automation.testing.pages.FlipkartHomePage;
import org.automation.testing.pages.ProductPage;
import org.automation.testing.pages.SearchResultsPage;
import org.automation.testing.utility.BrowserUtils;
import org.automation.testing.utility.ConfigReader;
import org.testng.Assert;
import org.testng.annotations.Test;


public class TC_002_ProductDetailsTest extends BaseTest {
    private FlipkartHomePage homePage;
    private SearchResultsPage searchResultsPage;
    private String originalWindow;

    @Test(priority = 1, description = "Test 1: View Samsung S25 Product Details")
    public void testViewSamsungProductDetails() {
        System.out.println("\n========== PRODUCT DETAILS TEST STARTED ==========\n");
        System.out.println(">>> TEST 1: Viewing Samsung S25 Product Details...");

        driver.navigate().to(ConfigReader.getURL());
        originalWindow = driver.getWindowHandle();

        homePage = new FlipkartHomePage(driver);
        searchResultsPage = new SearchResultsPage(driver);

        homePage.searchProduct("samsung s25 ultra");
        System.out.println(" Searched for: samsung s25 ultra");

        BrowserUtils.waitForElementVisible(driver, ProductPage.RESULTS_LOCATOR);
        System.out.println(" Search results loaded");

        int price = searchResultsPage.getFirstProductPriceFromResults();
        System.out.println(" Product Price (from results): Rs " + price);

        // Click first product
        searchResultsPage.clickFirstProduct();
        System.out.println(" Clicked on first product");

        BrowserUtils.switchToWindowByTitle(driver, "Samsung Galaxy S25");
        System.out.println(" Switched to product details tab");

        Assert.assertTrue(price > 0, "Failed: Product price not found");
        BrowserUtils.takeScreenShot(driver, "TC_002_Test_1_SamsungProductDetails");
        

        driver.close();
        driver.switchTo().window(originalWindow);
    }

    @Test(priority = 2, description = "Test 2: View Apple iPhone 17 Product Details")
    public void testViewAppleProductDetails() {
        System.out.println("\n>>> TEST 2: Viewing Apple iPhone 17 Product Details...");

        driver.navigate().to(ConfigReader.getURL());
        originalWindow = driver.getWindowHandle();

        homePage = new FlipkartHomePage(driver);
        searchResultsPage = new SearchResultsPage(driver);

        homePage.searchProduct("apple 17");
        System.out.println(" Searched for: apple 17");

        BrowserUtils.waitForElementVisible(driver, ProductPage.RESULTS_LOCATOR);
        System.out.println(" Search results loaded");

        int price = searchResultsPage.getFirstProductPriceFromResults();
        System.out.println(" Product Price (from results): Rs " + price);

        searchResultsPage.clickFirstProduct();
        System.out.println(" Clicked on first product");

        BrowserUtils.switchToWindowByTitle(driver, "apple 17");
        System.out.println(" Switched to product details tab");

        Assert.assertTrue(price > 0, "Failed: Product price not found");
        BrowserUtils.takeScreenShot(driver, "TC_002_Test_2_AppleProductDetails");

        driver.close();
        driver.switchTo().window(originalWindow);
    }

    @Test(priority = 3, description = "Test 3: View OnePlus Nord Product Details")
    public void testViewOnePlusProductDetails() {
        System.out.println("\n>>> TEST 3: Viewing OnePlus Nord Product Details...");

        driver.navigate().to(ConfigReader.getURL());
        originalWindow = driver.getWindowHandle();

        homePage = new FlipkartHomePage(driver);
        searchResultsPage = new SearchResultsPage(driver);

        homePage.searchProduct("oneplus nord");
        System.out.println(" Searched for: oneplus nord");

        BrowserUtils.waitForElementVisible(driver, ProductPage.RESULTS_LOCATOR);
        System.out.println(" Search results loaded");

        int price = searchResultsPage.getFirstProductPriceFromResults();
        System.out.println(" Product Price (from results): Rs " + price);

        searchResultsPage.clickFirstProduct();
        System.out.println(" Clicked on first product");

        BrowserUtils.switchToWindowByTitle(driver, "oneplus nord");
        System.out.println(" Switched to product details tab");

        Assert.assertTrue(price > 0, "Failed: Product price not found");
        BrowserUtils.takeScreenShot(driver, "TC_002_Test_3_OnePlusProductDetails");

        driver.close();
        driver.switchTo().window(originalWindow);
    }


}
