package org.automation.testing.utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;


public class ConfigReader {
    private static Properties properties;

    static {
        try {
            properties = new Properties();
            String configPath = System.getProperty("user.dir") + File.separator + "config.properties";
            FileInputStream fileInputStream = new FileInputStream(configPath);
            properties.load(fileInputStream);
            fileInputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static String getURL() {
        return properties.getProperty("URL");
    }

    public static String getBrowser() {
        return properties.getProperty("browser");
    }

   
}
