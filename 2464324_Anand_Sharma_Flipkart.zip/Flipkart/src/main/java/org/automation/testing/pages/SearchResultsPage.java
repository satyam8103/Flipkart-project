package org.automation.testing.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;


public class SearchResultsPage {
    private WebDriver driver;
    private static final Duration WAIT = Duration.ofSeconds(3);

    public SearchResultsPage(WebDriver driver) {
        this.driver = driver;
    }

    public void clickFirstProduct() {
        new WebDriverWait(driver, WAIT)
                .until(ExpectedConditions.elementToBeClickable(By.xpath("(.//div[@class=\"RG5Slk\"])[1]"))).click();
    }


    public int getFirstProductPriceFromResults() {
        try {
            String priceText = new WebDriverWait(driver, WAIT)
                    .until(ExpectedConditions
                            .visibilityOfElementLocated(By.xpath("(//*[@class=\"hZ3P6w DeU9vF\"])[1]")))
                    .getText();
            String digits = priceText.replaceAll("[^0-9]", "");
            return digits.isEmpty() ? 0 : Integer.parseInt(digits);
        } catch (Exception e) {
            return 0;
        }
    }
}
