package org.automation.testing.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;
import java.util.List;

public class ProductPage {
    private WebDriver driver;
    private static final int DEFAULT_WAIT = 10;

    // Locators
    private static final By ADDITIONAL_PRICE_LOCATOR = By.xpath("//div[@class=\"Eexxx2\"]");
    private static final By CART_TOTAL_LOCATOR = By.xpath("(//*[@class=\"oyozru\"])[2]//span");
    private static final By ADD_TO_CART_BY = By.xpath("//*[@class=\"dSM5Ub ugg2XR IUmgrZ\"]");
    private static final By ADD_TO_CART_ALTERNATE = By.xpath("(//div[@class='css-175oi2r' and contains(@style, 'height:44px')]/div[1])[2]");
    private static final By HOMEPAGE_ALTERNATIVE_CLASS = By.xpath("//div[contains(@class,'uRvp6e')]");
    private static final By PROTECT_PRICE_LOCATOR = By.xpath("(//div[contains(text(),'Protect')])");
    private static final By CART_ICON = By.xpath("//img[@alt='Cart']");
    public static final By RESULTS_LOCATOR = By.xpath("(.//div[@class=\"RG5Slk\"])");

    public ProductPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public void addToCart() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(DEFAULT_WAIT));
        // Determine preferred locator (prefer alternate if present)
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(1));
        By finalLocator = (driver.findElements(ADD_TO_CART_ALTERNATE).size() > 0) ? ADD_TO_CART_ALTERNATE : ADD_TO_CART_BY;
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(DEFAULT_WAIT));

        try {
            // Primary attempt
            WebElement btn = wait.until(ExpectedConditions.elementToBeClickable(finalLocator));
            btn.click();
            Thread.sleep(1500);
            return;
        } catch (Exception primaryEx) {
            System.out.println("Primary add-to-cart click failed, attempting fallback locator...");
           
        }
    }

    public int getAdditionalPrice() {
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(0));
        try {
            List<WebElement> elements = driver.findElements(ADDITIONAL_PRICE_LOCATOR);
            return elements.isEmpty() ? 0 : parsePrice(elements.get(0).getText());
        } finally {
            driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(DEFAULT_WAIT));
        }
    }


    public int getCartFinalPrice() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
        try {
            String priceText = wait.until(ExpectedConditions.refreshed(
                ExpectedConditions.presenceOfElementLocated(CART_TOTAL_LOCATOR)
            )).getText();
            return parsePrice(priceText);
        } catch (Exception e) {
            return 0;
        }
    }

    private int parsePrice(String priceString) {
        if (priceString == null || priceString.isEmpty()) return 0;
        String digits = priceString.replaceAll("[^0-9]", "");
        return digits.isEmpty() ? 0 : Integer.parseInt(digits);
    }

    public boolean isAlternativeHomepage() {
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(3));
        try {
            return driver.findElements(HOMEPAGE_ALTERNATIVE_CLASS).size() > 0;
        } finally {
            driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(DEFAULT_WAIT));
        }
    }

    public int getProtectPrice() {
        try {
            String text = driver.findElement(PROTECT_PRICE_LOCATOR).getText();
            String numberOnly = text.replaceAll("\\D+", "");
            return numberOnly.isEmpty() ? 0 : Integer.parseInt(numberOnly);
        } catch (Exception e) {
            return 0;
        }
    }

    public void clickCartIcon() {
        try {
            driver.findElement(CART_ICON).click();
        } catch (Exception e) {
            System.out.println("Could not click cart icon: " + e.getMessage());
        }
    }
}