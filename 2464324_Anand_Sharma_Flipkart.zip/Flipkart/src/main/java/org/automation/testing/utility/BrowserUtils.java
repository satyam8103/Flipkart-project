package org.automation.testing.utility;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.File;
import java.io.IOException;
import java.time.Duration;


public class BrowserUtils {
    private static final Duration WAIT = Duration.ofSeconds(10);

    public static void waitForElementVisible(WebDriver driver, By locator) {
        new WebDriverWait(driver, WAIT).until(ExpectedConditions.visibilityOfElementLocated(locator));
    }

    public static void switchToWindowByTitle(WebDriver driver, String titleContains) {
        for (String window : driver.getWindowHandles()) {
            driver.switchTo().window(window);
            if (driver.getTitle().contains(titleContains))
                return;
        }
    }


    public static void takeScreenShot(WebDriver driver, String name) {
        TakesScreenshot ts = (TakesScreenshot) driver;
        try {
            File screenshotsDir = new File(System.getProperty("user.dir") + File.separator + "Screenshots");
            if (!screenshotsDir.exists()) {
                screenshotsDir.mkdirs();
            }

            File dest = new File(screenshotsDir, name + ".jpeg");
            FileUtils.copyFile(ts.getScreenshotAs(OutputType.FILE), dest);
            System.out.println(" [SCREENSHOT] " + name + ": Screenshot has been captured -> " + dest.getAbsolutePath());
        } catch (IOException e) {
            System.out.println(" [SCREENSHOT ERROR] Failed to capture screenshot: " + name);
            e.printStackTrace();
        }
    }

    
}
