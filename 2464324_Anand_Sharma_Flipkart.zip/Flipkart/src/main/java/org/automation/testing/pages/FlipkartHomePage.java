package org.automation.testing.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import java.time.Duration;


public class FlipkartHomePage {
    private WebDriver driver;
    private static final Duration WAIT = Duration.ofSeconds(10);

    @FindBy(name = "q")
    private WebElement searchBox;

    public FlipkartHomePage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public void searchProduct(String productName) {
        new WebDriverWait(driver, WAIT).until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@name=\"q\"]")));
        searchBox.sendKeys(productName + Keys.ENTER);
    }

    public void clearAndSearchProduct(String productName) {
        // Wait for search box to be visible and clickable before sending keys
        new WebDriverWait(driver, WAIT).until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@name=\"q\"]")));
        searchBox.sendKeys(Keys.CONTROL, "a", Keys.BACK_SPACE);
        searchBox.sendKeys(productName + Keys.ENTER);
    }
}
